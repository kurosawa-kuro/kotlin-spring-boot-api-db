package com.example.kotlinspringcrudwebapi

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KotlinSpringCrudWebApiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
